SELECT COUNT(*) No_Rows FROM Emp;

SELECT MAX(Basic_Salary) Maximum_Salary FROM Emp;

SELECT MIN(Basic_Salary) Minimum_Salary FROM Emp;

SELECT SUM(Basic_Salary) Full_Payment FROM Emp;

SELECT AVG(Basic_Salary) Average_Salary FROM Emp;

