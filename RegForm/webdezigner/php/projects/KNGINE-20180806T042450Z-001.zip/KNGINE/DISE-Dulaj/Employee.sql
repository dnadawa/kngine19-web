CREATE TABLE Emp(
EmpID varchar(10) Primary Key,
EName varchar(50) not null,
DOB datetime ,
ConNo varchar(10),
NIC varchar(12) unique,
City varchar(10),
Age decimal(2,0),
Gender char(1) not null CHECK(Gender='M' or Gender='F'),
Basic_Salary decimal(8,2) default '0.00' 
);


