import java.util.Scanner;

public class grade{
public static void main(String args[]){
	
	Scanner gd=new Scanner(System.in);
	
	System.out.println("");
	System.out.println("     EXAM GRADING SYSTEM     ");
	System.out.println("-----------------------------");
	System.out.println("");
	
	System.out.print("Enter Student ID:");
	String id=gd.next();
	
	System.out.println("Enter Your Marks:");
	System.out.print("Python: ");
	double mpy=gd.nextDouble();
	System.out.print("JAVA: ");
	double mjava=gd.nextDouble();
	System.out.print("C#: ");
	double mc=gd.nextDouble();
	
	double tot=mpy+mjava+mc;
	double avg=tot/3;
	//avg=Math.round(avg);
	char g;
	if(avg>=80){g='A';}
	else if(avg>=60){g='B';}
	else if(avg>=50){g='C';}
	else if(avg>=40){g='S';}
	else{g='W';}
	
	String wish,st;
	
	if(g=='W'){wish="Sorry!";st="Repeat";}
	else{wish="Congratulations!";st="Pass";}
	
	
	
	System.out.println("==============================\n");
	System.out.println("Student ID: "+id);
	System.out.println("Pyhon: "+mpy);
	System.out.println("JAVA: "+mjava);
	System.out.println("C#: "+mc);
	System.out.println("\nTotal: "+tot);
	System.out.println("Average: "+avg);
	System.out.println("Grade: "+g);
	System.out.println("\n==============================\n");
	
	System.out.println("Dear Student,\n"+wish+" You have "+st+" the exam!!!");
	
	
	
	
	
	
	
	
}
}