public class patex{
public static void main(String args[]){
	
	for (int i=0; i<6; i++){
		
		
		for (int k=0; k<5-i; k++){
			System.out.print(" ");
		}
		for (int j=0; j<i*2+1; j++){
			System.out.print("*");
		}
    

	System.out.println("");
  }
  
  
  
  for (int i=0; i<6; i++){
		
		
		for (int k=5+1; k>0; k--){
			System.out.print(" ");
		}
		for (int j=0; j<i*2+1; j++){
			System.out.print("*");
		}
    

	System.out.println("");
  }
        



}
}