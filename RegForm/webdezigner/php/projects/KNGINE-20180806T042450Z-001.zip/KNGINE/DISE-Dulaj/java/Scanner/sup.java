import java.util.Scanner;
import java.text.DecimalFormat;


public class sup{

private static DecimalFormat df=new DecimalFormat("#.##");

public static void main(String args[]){

Scanner userin=new Scanner(System.in);

System.out.println("\n****SUPER MARKET SYSTEM****");
System.out.println("---------------------------\n");

System.out.print("Enter Customer No: ");
String cus=userin.next();

System.out.print("Enter Number of Items: ");
int num=userin.nextInt();
System.out.println("\n");
double itm,qty,disr,disa,dis,pay;
double val=0.0;
double tot=0.0;
qty=itm=pay=disr=disa=dis=0;

for(int x=1;x<=num;x++){
	System.out.print("Item "+x+" Price: Rs.");
	itm=userin.nextDouble();
	System.out.print("Item "+x+" Quantity: ");
	qty=userin.nextDouble();

	val=itm*qty;
	tot=tot+val;
	
}


if(tot>=20000){dis=0.15;}
else if(tot>=15000){dis=0.1;}
else if(tot>=10000){dis=0.05;}
else if(tot>=5000){dis=0.02;}
else {dis=0.0;}

disr=dis*100;
disa=tot*dis;
pay=tot-disa;

tot=Double.valueOf(df.format(tot));
disa=Double.valueOf(df.format(disa));
pay=Double.valueOf(df.format(pay));


System.out.println("\n===========================\n");
System.out.println("Bill for Customer Number "+cus+"!\n");
System.out.println("Value Of Goods: Rs."+tot);
System.out.println("Discount Rate: "+disr+"%");
System.out.println("Discount Amount: Rs."+disa);
System.out.println("Amount to Pay: Rs."+pay);
System.out.println("\n===========================\n");
System.out.println("Thank You! Come Again!!!");





}
}