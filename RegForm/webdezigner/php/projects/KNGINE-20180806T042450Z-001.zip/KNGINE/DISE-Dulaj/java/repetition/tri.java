public class tri{
public static void main(String args[]){

String y="*****";


for(int x=0;x<5;x++){
	
	System.out.println(y);

	
	}




}
}