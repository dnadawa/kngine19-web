public class hash{
public static void main(String args[]){

String y="######";


for(int x=1;x<=6;x++){
	
	System.out.println(y);
}


System.out.println("#####");
System.out.println("####");
System.out.println("###");
System.out.println("##");
System.out.println("#");




}
}