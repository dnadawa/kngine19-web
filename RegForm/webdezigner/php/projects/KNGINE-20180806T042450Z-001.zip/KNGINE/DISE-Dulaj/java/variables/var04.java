public class var04{
	public static void main(String args[]){
		double f=25.324;
		System.out.println(f);
	}
}