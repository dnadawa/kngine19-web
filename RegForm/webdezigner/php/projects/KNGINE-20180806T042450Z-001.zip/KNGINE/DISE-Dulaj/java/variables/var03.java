public class var03{
	public static void main(String args[]){
		float f=25.324f;
		System.out.println(f);
	}
}