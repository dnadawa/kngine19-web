public class var02{
	public static void main(String args[]){
		short as=3524;
		System.out.println(as);
	}
}