import java.awt.*;
import java.awt.event.*;
import java.applet.*;

public class salSys extends Applet implements ActionListener{
Label L1,L2,L3,L4,L5,L6,L7,L8,L9,L10,L11,L12,L13,L14,L15,L16,L17,L18,L19,L20,L21,L22,L23;
TextField T1,T2,T3,T4,T5,T6;
Button B1,B2,B3;


	
public void init(){
setLayout(new GridLayout(8,4));


//1row
L1=new Label("Salary System");
add(L1);
L2=new Label(">>>>>>>>>>>>>");
add(L2);
L3=new Label("");
add(L3);
L4=new Label("");
add(L4);

//2row
L5=new Label("Employee ID");
add(L5);
T1=new TextField();
add(T1);
L6=new Label("Name");
add(L6);
T2=new TextField();
add(T2);

//3row
L7=new Label("Hours Worked");
add(L7);
T3=new TextField();
add(T3);
L8=new Label("Hourly Rate");
add(L8);
T4=new TextField();
add(T4);

//4row
L9=new Label("");
add(L9);
B1=new Button("Basic Salary");
add(B1);
B1.addActionListener(this);
L10=new Label("");
add(L10);
L11=new Label("");
add(L11);

//5row
L12=new Label("Basic Salary");
add(L12);
L13=new Label("");
add(L13);
L14=new Label("OT");
add(L14);
T5=new TextField();
add(T5);

//6row
L15=new Label("Bonus");
add(L15);
L16=new Label("");
add(L16);
L17=new Label("Deduction");
add(L17);
T6=new TextField();
add(T6);

//7row
L18=new Label("");
add(L18);
B2=new Button("Payment");
add(B2);
B2.addActionListener(this);
L19=new Label("");
add(L19);
B3=new Button("CLEAR");
add(B3);
B3.addActionListener(this);

//8row
L20=new Label("Net Salary");
add(L20);
L21=new Label("");
add(L21);
L22=new Label("");
add(L22);
L23=new Label("");
add(L23);

}




public void actionPerformed(ActionEvent q){
	
	
	
	
	if(q.getSource()==B3){
	T1.setText(" ");
	T2.setText(" ");
	T3.setText(" ");
	T4.setText(" ");
	T5.setText(" ");
	T6.setText(" ");
	L13.setText(" ");
	L16.setText(" ");
	L21.setText(" ");
	T1.requestFocus();
}

	int bonus;
	double hw=Double.parseDouble(T3.getText());
	double hr=Double.parseDouble(T4.getText());
	double bs=hw*hr;
	
	
if(bs>=35000){bonus=5000;}
else if(bs>=25000){bonus=3000;}
else if(bs>=20000){bonus=2500;}
else {bonus=1000;}
	
	
	
	
if(q.getSource()==B1){
	
	
	L13.setText("Rs."+String.valueOf(bs));
	L16.setText("Rs."+String.valueOf(bonus));
}


if(q.getSource()==B2){
	double ot=Double.parseDouble(T5.getText());
	double ded=Double.parseDouble(T6.getText());
	
	
	
	double netsal=(bs+bonus+ot)-ded;
	
	L21.setText("Rs."+String.valueOf(netsal));
}






	
	
	}
}