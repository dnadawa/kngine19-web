public class for06{
public static void main(String args[]){
	int y=0;
	for(int x=1;x<=12;x++){
		y=y+x;
		
		System.out.println(y);
		
		
		
		
	}


}
}