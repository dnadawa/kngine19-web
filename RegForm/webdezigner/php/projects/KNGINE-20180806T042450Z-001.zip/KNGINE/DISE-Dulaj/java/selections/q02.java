public class q02{
public static void main(String args[]){

double vog=5500.00;
double dis;

if(vog>=10000){dis=10;}
else if(vog>=7500){dis=8;}
else if(vog>=5000){dis=6;}
else if(vog>=3500){dis=5;}
else if(vog>=2500){dis=2.5;}
else{dis=0;}

double atp=vog-(vog*dis/100);

System.out.println("Total: Rs."+atp);

}
}