public class for05{
public static void main(String args[]){

	for(x=1;x<=144;x++){
	
		x=x^x;
		System.out.println(x);
	
	}
	
	
	
}
}