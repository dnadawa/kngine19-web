public class op1{
	public static void main(String args[]){
		int x=42;
		int y=45;
		int z=x+y;
		
		System.out.println(z);
	}
}