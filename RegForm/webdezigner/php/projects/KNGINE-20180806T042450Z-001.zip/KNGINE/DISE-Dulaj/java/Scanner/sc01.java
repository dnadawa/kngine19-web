import java.util.Scanner;

public class sc01{
public static void main(String args[]){
	
	Scanner mys=new Scanner(System.in);
	System.out.print("Enter Your name: ");
	String name=mys.next();
	System.out.print("Enter Your age: ");
	int age=mys.nextInt();
	System.out.print("Hi "+name+" ! Your Age is "+age+"!");
	
}
}