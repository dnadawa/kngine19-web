public class sel03{
	
public static void main(String args[]){
	
String EmpNo= "EM5676";
double hw=65;
double hr=142.24;

double bs=hw*hr;
double bonus;

if(hw<50){
	bonus=5000.00;
}
else if(hw<40){
	bonus=4000.00;
}
else if(hw<35){
	bonus=3000.00;
}
else if(hw<25){
	bonus=2500.00;
}
else{
	bonus=0;
}

System.out.println(EmpNo+" your salary is Rs."+(bs+bonus));


	
}
}