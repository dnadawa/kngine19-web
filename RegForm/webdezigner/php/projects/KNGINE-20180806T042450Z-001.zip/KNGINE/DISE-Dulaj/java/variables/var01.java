public class var01{
	public static void main(String args[]){
		byte x=42;
		System.out.println(x);
	}
}