public class for05{
public static void main(String args[]){

	for(int x=1;x<=12;x++){
	
		int y=x*x;
		System.out.println(y);
	
	}
	
	
	
}
}