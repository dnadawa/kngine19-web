public class op4{
	public static void main(String args[]){
		double x=9;
		double y=786;
		double z=x*y;
		
		System.out.println(z);
	}
}