public class op5{
	public static void main(String args[]){
		int x=25;
		int y=7;
		int z=x%y;
		
		System.out.println(z);
	}
}