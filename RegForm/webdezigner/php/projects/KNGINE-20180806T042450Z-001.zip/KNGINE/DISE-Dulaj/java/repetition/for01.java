public class for01{
public static void main(String args[]){
for(int x=5;x<=15;x++){
System.out.print(x+",");
}
}
}