public class hash1{
public static void main(String args[]){

String y="";


for(int x=1;x<=11;x++){
	
	if(x<=6){
		y="######";
	}
	
	else{
		y=y+"#";
	}
	
	System.out.println(y);
	
	
	
}





}
}