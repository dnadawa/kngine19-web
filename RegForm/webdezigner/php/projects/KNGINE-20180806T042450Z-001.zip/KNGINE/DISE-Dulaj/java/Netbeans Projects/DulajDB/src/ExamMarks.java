
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DecimalFormat;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class ExamMarks extends javax.swing.JFrame {

    /**
     * Creates new form ExamMarks
     */
    public ExamMarks() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton2 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        jButton4 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        btncal = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        mytable = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txtoop = new javax.swing.JTextField();
        txtjava = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtsql = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        btnref = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        txttot = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txtavg = new javax.swing.JTextField();
        txtgrade = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        btnsave = new javax.swing.JButton();
        btnexit = new javax.swing.JButton();
        btnclear = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        txtsid = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txtsname = new javax.swing.JTextField();

        jButton2.setText("REFRESH");

        jLabel5.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        jLabel5.setText("OOP");

        jTextField4.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N

        jButton4.setText("CALCULATE");

        jButton6.setText("CALCULATE");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Student Grading System");
        setResizable(false);

        jLabel1.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 0, 0));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Student Grading System");

        btncal.setText("CALCULATE");
        btncal.setEnabled(false);
        btncal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncalActionPerformed(evt);
            }
        });
        btncal.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                btncalKeyPressed(evt);
            }
        });

        mytable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Student ID", "Student  Name"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        mytable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mytableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(mytable);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3), "Exam Marks", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Dialog", 1, 14), new java.awt.Color(255, 0, 0))); // NOI18N

        jLabel2.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        jLabel2.setText("OOP");

        txtoop.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        txtoop.setEnabled(false);

        txtjava.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        txtjava.setEnabled(false);

        jLabel3.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        jLabel3.setText("JAVA");

        txtsql.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        txtsql.setEnabled(false);

        jLabel4.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        jLabel4.setText("SQL");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4))
                .addGap(32, 32, 32)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtsql)
                    .addComponent(txtjava)
                    .addComponent(txtoop))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtoop, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtjava, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtsql, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        btnref.setText("REFRESH");
        btnref.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnrefActionPerformed(evt);
            }
        });
        btnref.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                btnrefKeyPressed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        jLabel6.setText("Total");

        txttot.setEditable(false);
        txttot.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N

        jLabel7.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        jLabel7.setText("Average");

        txtavg.setEditable(false);
        txtavg.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N

        txtgrade.setEditable(false);
        txtgrade.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N

        jLabel8.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        jLabel8.setText("Grade");

        btnsave.setText("SAVE");
        btnsave.setEnabled(false);
        btnsave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsaveActionPerformed(evt);
            }
        });
        btnsave.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                btnsaveKeyPressed(evt);
            }
        });

        btnexit.setText("EXIT");
        btnexit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnexitActionPerformed(evt);
            }
        });
        btnexit.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                btnexitKeyPressed(evt);
            }
        });

        btnclear.setText("CLEAR");
        btnclear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnclearActionPerformed(evt);
            }
        });
        btnclear.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                btnclearKeyPressed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        jLabel9.setText("Student ID");

        txtsid.setEditable(false);
        txtsid.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N

        jLabel10.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N
        jLabel10.setText("Student Name");

        txtsname.setEditable(false);
        txtsname.setFont(new java.awt.Font("Adobe Caslon Pro", 0, 18)); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 284, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addComponent(btnref)
                        .addGap(10, 10, 10))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addGap(37, 37, 37)
                                .addComponent(txttot, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel7)
                                    .addComponent(jLabel8))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtgrade, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtavg, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btncal)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnsave)
                        .addGap(18, 18, 18)
                        .addComponent(btnclear)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnexit)
                        .addGap(23, 23, 23))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addGap(37, 37, 37)
                        .addComponent(txtsid)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtsname)
                        .addContainerGap())))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(btnref))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(txtsid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(txtsname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btncal)
                    .addComponent(jLabel6)
                    .addComponent(txttot, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txtavg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(txtgrade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnsave)
                    .addComponent(btnexit)
                    .addComponent(btnclear))
                .addGap(18, 18, 18))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private static DecimalFormat dd=new DecimalFormat("#.##");
    
    
    private void save(){
    try {
    Class.forName("java.sql.Driver");
    Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/dulajdb","root","");
    
    String saveque="INSERT INTO exammarks(StID,SName,OOP,JAVA,SQLm,Total,Average,Grade) VALUES (?,?,?,?,?,?,?,?)";
    
    PreparedStatement cmd=con.prepareStatement(saveque);
    cmd.setString(1, txtsid.getText());
    cmd.setString(2, txtsname.getText());
    cmd.setString(3, txtoop.getText());
    cmd.setString(4, txtjava.getText());
    cmd.setString(5, txtsql.getText());
    cmd.setString(6, txttot.getText());
    cmd.setString(7, txtavg.getText());
    cmd.setString(8, txtgrade.getText());
    cmd.execute();
    
    JOptionPane.showMessageDialog(this, "Exam Results of "+txtsid.getText()+" is successfully SAVED to the table!","SAVE",JOptionPane.INFORMATION_MESSAGE);
    clear();
    ref();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error while Save \n"+ex);
        }
    
    }
    
    
    private void btnsaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsaveActionPerformed
        
        save();
        
        
        
    }//GEN-LAST:event_btnsaveActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton6ActionPerformed

    private void exit(){
    int res=JOptionPane.showConfirmDialog(null, "Are you sure you want to exit?","Exit",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE);
        if(res==0){
           // System.exit(0);
           this.dispose();
        }
    }
    
    
    private void btnexitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnexitActionPerformed
        exit();
    }//GEN-LAST:event_btnexitActionPerformed
private void ref(){
        DefaultTableModel mod=(DefaultTableModel)mytable.getModel();
        mod.setRowCount(0);
        
        try {
    Class.forName("java.sql.Driver");
    Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/dulajdb","root","");
    Statement st=con.createStatement();
    String selque="SELECT StID,SName FROM streg;";
    ResultSet rs=st.executeQuery(selque);
    
    while(rs.next()){
        String d1=rs.getString("StID");
        String d2=rs.getString("SName");
        
        
        mod.addRow(new Object[] {d1,d2});
    }
    
    rs.close();
    st.close();
    con.close();
    
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error While Refresh \n "+ex);
        }
    }
private void clear(){
        txtsid.setText("");
        txtsname.setText("");
        txtoop.setText("");
        txtjava.setText("");
        txtsql.setText("");
        txttot.setText("");
        txtavg.setText("");
        txtgrade.setText("");
        
        btnsave.setEnabled(false);
        btncal.setEnabled(false);
        txtoop.setEnabled(false);
        txtjava.setEnabled(false);
        txtsql.setEnabled(false);
        
        mytable.requestFocus();
    }



    private void btnrefActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnrefActionPerformed
        ref();
    }//GEN-LAST:event_btnrefActionPerformed

    private void btnclearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnclearActionPerformed
       clear();
    }//GEN-LAST:event_btnclearActionPerformed

    private void cal(){
    if(txtoop.getText().equals("")||txtjava.getText().equals("")||txtsql.getText().equals("")){
            JOptionPane.showMessageDialog(this, "Fields are Empty","Fill the Fields",JOptionPane.WARNING_MESSAGE);
            txtoop.requestFocus();
        }
        else{
            double oop,java,sql,tot,avg;
            char g;
             oop=Double.parseDouble(txtoop.getText());
             java=Double.parseDouble(txtjava.getText());
             sql=Double.parseDouble(txtsql.getText());
            
             tot=oop+java+sql;
             
             avg=tot/3;
             avg=Double.valueOf(dd.format(avg));
             if(avg>=80){g='A';}
             else if(avg>=70){g='B';}
             else if(avg>=60){g='C';}
             else if(avg>=40){g='S';}
             else{g='W';}
             
             btnsave.setEnabled(true);
             txttot.setText(String.valueOf(tot));
             txtavg.setText(String.valueOf(avg));
             txtgrade.setText(String.valueOf(g));
            
            
            
            
            
        }
    
    }
    
    
    
    private void btncalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncalActionPerformed
        cal();
    }//GEN-LAST:event_btncalActionPerformed

    private void mytableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mytableMouseClicked
        try {
            Class.forName("java.sql.Driver");
    Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/dulajdb","root","");
    
    
    int row=mytable.getSelectedRow();
    String rc=(mytable.getModel()).getValueAt(row, 0).toString();
    String selque="SELECT StID,SName FROM streg WHERE StID='"+rc+"';";
    Statement st=con.createStatement();
    ResultSet rs=st.executeQuery(selque);
    if(rs.next()){
        String sid=rs.getString("StID");
        txtsid.setText(sid);
        
        String sname=rs.getString("SName");
        txtsname.setText(sname);
        
        
         
        txtoop.setEnabled(true);
        txtjava.setEnabled(true);
        txtsql.setEnabled(true);
        btncal.setEnabled(true);
        
        
    }
        } catch (Exception ex) {
           JOptionPane.showMessageDialog(this, "Error while load to the form \n"+ex); 
            
        }
    }//GEN-LAST:event_mytableMouseClicked

    private void btnrefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_btnrefKeyPressed
        if(evt.getKeyCode()==KeyEvent.VK_ENTER){
        ref();
        }
    }//GEN-LAST:event_btnrefKeyPressed

    private void btnclearKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_btnclearKeyPressed
        if(evt.getKeyCode()==KeyEvent.VK_ENTER){
        clear();
        }
    }//GEN-LAST:event_btnclearKeyPressed

    private void btnexitKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_btnexitKeyPressed
        if(evt.getKeyCode()==KeyEvent.VK_ENTER){
        exit();
        }
    }//GEN-LAST:event_btnexitKeyPressed

    private void btncalKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_btncalKeyPressed
        if(evt.getKeyCode()==KeyEvent.VK_ENTER){
        cal();
        }
       
        
        
        
    }//GEN-LAST:event_btncalKeyPressed

    private void btnsaveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_btnsaveKeyPressed
        if(evt.getKeyCode()==KeyEvent.VK_ENTER){
        save();
        }
    }//GEN-LAST:event_btnsaveKeyPressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ExamMarks.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ExamMarks.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ExamMarks.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ExamMarks.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ExamMarks().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btncal;
    private javax.swing.JButton btnclear;
    private javax.swing.JButton btnexit;
    private javax.swing.JButton btnref;
    private javax.swing.JButton btnsave;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTable mytable;
    private javax.swing.JTextField txtavg;
    private javax.swing.JTextField txtgrade;
    private javax.swing.JTextField txtjava;
    private javax.swing.JTextField txtoop;
    private javax.swing.JTextField txtsid;
    private javax.swing.JTextField txtsname;
    private javax.swing.JTextField txtsql;
    private javax.swing.JTextField txttot;
    // End of variables declaration//GEN-END:variables
}
