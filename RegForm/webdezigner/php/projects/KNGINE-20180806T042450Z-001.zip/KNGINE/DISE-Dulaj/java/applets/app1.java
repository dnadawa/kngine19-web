import java.awt.*;
import java.awt.event.*;
import java.applet.*;

public class app1 extends Applet implements ActionListener{
Label L1,L2,L3;
TextField T1,T2;
Button B;
	
public void init(){
setLayout(new GridLayout(3,2));

L1=new Label("Name");
add(L1);
T1=new TextField();
add(T1);

L2=new Label("Age");
add(L2);
T2=new TextField();
add(T2);

L3=new Label("");
add(L3);

B=new Button("OK");
add(B);
B.addActionListener(this);
}

public void actionPerformed(ActionEvent e){
	
if(e.getSource()==B){
	T1.setText(" ");
	T2.setText(" ");
	T1.requestFocus();
}

	
}
	
	
	
	
	}