import java.util.Scanner;

public class addsc{
public static void main(String args[]){
	
	Scanner cal=new Scanner(System.in);
	System.out.print("Enter First Number: ");
	double n1=cal.nextDouble();
	System.out.print("Enter Second Number: ");
	double n2=cal.nextDouble();
	double n3=n1+n2;
	System.out.print("Answer is: "+n3);
	
}
}