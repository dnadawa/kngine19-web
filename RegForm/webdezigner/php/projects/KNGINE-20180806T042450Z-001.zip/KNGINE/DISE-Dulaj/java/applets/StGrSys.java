import java.awt.*;
import java.awt.event.*;
import java.applet.*;

public class StGrSys extends Applet implements ActionListener{
Label L1,L2,L3,L4,L5,L6,L7,L8,L9,L10,L11,L12,L13,L14,L15,L16,L17;;
TextField T1,T2,T3,T4,T5;
Button B1,B2;


	
public void init(){
setLayout(new GridLayout(8,3));


//1row
L1=new Label("Student ID");
add(L1);
T1=new TextField();
add(T1);
L2=new Label("");
add(L2);


//2row
L3=new Label("Student Name");
add(L3);
T2=new TextField();
add(T2);
L4=new Label("");
add(L4);

//3row
L5=new Label("PDM");
add(L5);
T3=new TextField();
add(T3);
L6=new Label("");
add(L6);

//4row
L7=new Label("Fundamentals");
add(L7);
T4=new TextField();
add(T4);
L8=new Label("");
add(L8);

//5row
L9=new Label("JAVA");
add(L9);
T5=new TextField();
add(T5);
L10=new Label("");
add(L10);

//6row
L11=new Label("Total");
add(L11);
L12=new Label("");
add(L12);
L13=new Label("");
add(L13);

//7row
L14=new Label("Average");
add(L14);
L15=new Label("");
add(L15);
B1=new Button("GRADE");
add(B1);
B1.addActionListener(this);

//row8
L16=new Label("Grade");
add(L16);
L17=new Label("");
add(L17);
B2=new Button("CLEAR");
add(B2);
B2.addActionListener(this);



}




public void actionPerformed(ActionEvent d){
	

	
	if(d.getSource()==B2){
	T1.setText(" ");
	T2.setText(" ");
	T3.setText(" ");
	T4.setText(" ");
	T5.setText(" ");
	L12.setText(" ");
	L15.setText(" ");
	L17.setText(" ");
	T1.requestFocus();
}

	
	
	
if(d.getSource()==B1){
	
	 
	 double pdm=Double.parseDouble(T3.getText());
	 double fun=Double.parseDouble(T4.getText());
	 double java=Double.parseDouble(T5.getText());
	 double tot=pdm+fun+java;
	 double avg=tot/3;
	 char g;
	 
	 if(avg>=75){g='A';}
	 else if(avg>=65){g='B';}
	 else if(avg>=55){g='C';}
	 else if(avg>=35){g='S';}
	 else{g='W';}
	 
	 L12.setText(String.valueOf(tot));
	 L15.setText(String.valueOf(avg));
	 L17.setText(String.valueOf(g));
	 
}



}
}