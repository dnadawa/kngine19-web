import java.util.Scanner;

public class addsc2{
public static void main(String args[]){
	Scanner cal=new Scanner(System.in);
	
	
	
	
	System.out.print("Enter First Number: ");
	double n1=cal.nextDouble();
	System.out.print("Enter Second Number: ");
	double n2=cal.nextDouble();
	
	System.out.print("What do you want to do?   :");
	String sign=cal.next();
	if(sign.equals("+")){
		double n3=n1+n2;
	System.out.print("Answer is: "+n3);
	}
	else if(sign.equals("-")){
		double n3=n1-n2;
	System.out.print("Answer is: "+n3);
	}
	else if(sign.equals("*")){
		double n3=n1*n2;
	System.out.print("Answer is: "+n3);
	}
	else if(sign.equals("/")){
		double n3=n1/n2;
	System.out.print("Answer is: "+n3);
	}
}
}