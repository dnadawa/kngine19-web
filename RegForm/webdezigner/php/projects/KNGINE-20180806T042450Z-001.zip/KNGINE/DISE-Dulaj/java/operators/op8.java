public class op8{
	public static void main(String args[]){
		int x=9;
		int y=x--;
		
		
		System.out.println(y);
	}
}