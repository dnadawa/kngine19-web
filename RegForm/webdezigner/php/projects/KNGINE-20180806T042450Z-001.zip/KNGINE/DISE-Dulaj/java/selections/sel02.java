public class sel02{
	
public static void main(String args[]){
	
int m=86;
char g;

if(m>=75){
	g='A';
		}	

else{
	if(m>=65){
		g='B';
		}
	else{
		if(m>=55){
		g='C';
		}
		else{
			if(m>=35){
				g='S';
					}
			else{
				g='W';
			}
			}
		}
	}
	
System.out.println("Your Grade is "+g+" !");
	
}
}