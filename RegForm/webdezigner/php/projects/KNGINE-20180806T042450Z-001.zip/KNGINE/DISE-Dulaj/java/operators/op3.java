public class op3{
	public static void main(String args[]){
		double x=35;
		double y=9;
		double z=x/y;
		
		System.out.println(z);
	}
}