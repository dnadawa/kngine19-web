public class sel01{
	
public static void main(String args[]){
	
int x=75;

	if(x>=60){
		System.out.println("Pass");
			}
	else{
		System.out.println("Fail");
			}

			

}
}