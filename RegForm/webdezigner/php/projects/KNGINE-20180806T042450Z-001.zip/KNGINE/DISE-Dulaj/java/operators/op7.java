public class op7{
	public static void main(String args[]){
		int x=12;
		int y=++x;
		
		
		System.out.println(y);
	}
}