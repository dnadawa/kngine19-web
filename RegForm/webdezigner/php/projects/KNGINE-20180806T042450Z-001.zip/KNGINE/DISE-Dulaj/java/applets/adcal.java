import java.awt.*;
import java.awt.event.*;
import java.applet.*;

public class adcal extends Applet implements ActionListener{
Label L1,L2,L3,L4;
TextField T1,T2;
Button add,min,mul,div,mod,clear;
	
public void init(){
setLayout(new GridLayout(4,3));

//1st row
L1=new Label("Value 01");
add(L1);
T1=new TextField();
add(T1);

add=new Button("+");
add(add);
add.addActionListener(this);


//2nd row
L2=new Label("Value 02");
add(L2);
T2=new TextField();
add(T2);


min=new Button("-");
add(min);
min.addActionListener(this);

//3rd row
L3=new Label("Answer");
add(L3);
L4=new Label("");
add(L4);

mul=new Button("*");
add(mul);
mul.addActionListener(this);

//4th row
clear=new Button("CLEAR");
add(clear);
clear.addActionListener(this);

mod=new Button("%");
add(mod);
mod.addActionListener(this);


div=new Button("/");
add(div);
div.addActionListener(this);


L4.setText("0.0");

}




public void actionPerformed(ActionEvent cal){
	
	double v1=Double.parseDouble(T1.getText());
	double v2=Double.parseDouble(T2.getText());
	
	double ans=0.0;
	
	if(cal.getSource()==clear){
	L4.setText(" ");
	T1.setText(" ");
	T2.setText(" ");
	T1.requestFocus();
}

	
	
	
if(cal.getSource()==add){
	
	 ans=v1+v2;
	L4.setText(String.valueOf(ans));
}

if(cal.getSource()==min){
	
	 ans=v1-v2;
	L4.setText(String.valueOf(ans));
}

if(cal.getSource()==mul){
	
	 ans=v1*v2;
	L4.setText(String.valueOf(ans));
}

if(cal.getSource()==div){
	
	 ans=v1/v2;
	L4.setText(String.valueOf(ans));
}

if(cal.getSource()==mod){
	
	 ans=v1%v2;
	L4.setText(String.valueOf(ans));
}






	
}



	
	
	
	
	}