public class op2{
	public static void main(String args[]){
		int x=68;
		int y=58;
		int z=x-y;
		
		System.out.println(z);
	}
}