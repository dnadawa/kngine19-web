public class titgen{
public static void main(String args[]){
String name="Manori";
String gen="Female";
String cs="Unmarried";
String tit;

if(gen=="Male"){
	tit="Mr. ";
}
else if(cs=="Married"){
	tit="Mrs. ";
	}
else{
	tit="Miss. ";
	}

	System.out.println("Welcome to JAVA, "+tit+name+"!");
	
}
}