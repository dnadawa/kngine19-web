public class var05{
	public static void main(String args[]){
		char as='d';
		System.out.println(as);
	}
}