CREATE DATABASE DISE_25;

CREATE TABLE new_Registration(
	sRegNo varchar(10) Primary Key,
	sName varchar(100) not null,
	NIC varchar(12) unique not null,
	sAddress varchar(200) Default 'Sri Lanka',
	Gender char(1) CHECK(Gender='M' OR Gender='F') not null
	);

--DROP TABLE new_Registration;

