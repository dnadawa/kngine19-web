﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Welcome
{
    public partial class Welcome_in_New_Way : Form
    {
        public Welcome_in_New_Way()
        {
            InitializeComponent();
        }

        private void btnclick_Click(object sender, EventArgs e)
        {
            String name = txtname.Text;
            if (name == "")
            {
                MessageBox.Show("Name cannot be empty!", "Fields are empty", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtname.Focus();
            }
            else
            {
                MessageBox.Show("Welcome to C#.Net " + name + "!", "Welcome", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtname.Text = "";
                txtname.Focus();

            }
        }
    }
}
