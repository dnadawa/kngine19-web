﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Welcome
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            txtname.Text = "";
            txtage.Text = "";
            cbcs.Text="Select";
            txtname.Focus();
            rbmale.Checked = false;
            rbfemale.Checked = false;
        }



        private void btnexit_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("Are you sure you want to exit?", "Exit?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res==DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void btnok_Click(object sender, EventArgs e)
        {
            String name, tit,age;
            name = txtname.Text;
            age = txtage.Text;

            if (rbmale.Checked == true)
            {
                tit = "Mr. ";
            }
            else if (cbcs.Text == "Married")
            {
                tit = "Mrs. ";
            }
            else
            {
                tit = "Miss. ";
            }

            MessageBox.Show(tit + name + " you are " + age + " year old!", tit + name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }
    }
}
