﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Welcome
{
    public partial class Simple_Calculator : Form
    {
        public Simple_Calculator()
        {
            InitializeComponent();
        }

        private void btncl_Click(object sender, EventArgs e)
        {
            txtv1.Text = "";
            txtv2.Text = "";
            lblans.Text = "";
            txtv1.Focus();
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
         

            double x, y;

            x = Double.Parse(txtv1.Text);
            y = Double.Parse(txtv2.Text);

            lblans.Text = (x + y).ToString();
        }

        private void btnmin_Click(object sender, EventArgs e)
        {
            double x, y;

            x = Double.Parse(txtv1.Text);
            y = Double.Parse(txtv2.Text);

            lblans.Text = (x - y).ToString();
        }

        private void btnmul_Click(object sender, EventArgs e)
        {
            double x, y;

            x = Double.Parse(txtv1.Text);
            y = Double.Parse(txtv2.Text);

            lblans.Text = (x * y).ToString();
        }

        private void btndiv_Click(object sender, EventArgs e)
        {
            double x, y;

            x = Double.Parse(txtv1.Text);
            y = Double.Parse(txtv2.Text);

            lblans.Text = (x / y).ToString();
        }

        private void btnmod_Click(object sender, EventArgs e)
        {
            double x, y;

            x = Double.Parse(txtv1.Text);
            y = Double.Parse(txtv2.Text);

            lblans.Text = (x % y).ToString();
        }
    }
}
