CREATE TABLE Course(
CID varchar(5) Primary Key,
CName varchar(50),
Duration varchar(10)

);


CREATE TABLE Student(
SNo varchar(10) Primary Key,
SName varchar(100),
DOB datetime,
Fee DEcimal(10,2) Default '0.00',
CID varchar(5) not null,
Constraint Fk_Student Foreign Key(CID) References Course(CID)


);