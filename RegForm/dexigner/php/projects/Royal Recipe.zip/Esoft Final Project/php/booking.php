<?php
echo "Hi";
header("Location: ../tablebook.php");
?>