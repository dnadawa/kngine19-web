<?php
include ('reg.php');
?>

<?php
/*
$cookie_name = "user";
$cookie_value = $un;
setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/");
*//*
if($un=="us"){
    echo "No logged";
}
else{
    echo "user logged".$_COOKIE[$cookie_name];
}
*/
echo $var;
?>








<?php
/*
$name=1;

if($name==1){
	echo "logged.html";
}

else{
    header('Location: login.html');
}
*/
?>


